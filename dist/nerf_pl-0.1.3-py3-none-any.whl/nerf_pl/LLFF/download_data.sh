cd checkpoints
wget http://cseweb.ucsd.edu/~viscomp/projects/LF/papers/SIG19/lffusion/llff_trained_model.zip
unzip llff_trained_model.zip
cd ..

cd data
wget http://cseweb.ucsd.edu/~viscomp/projects/LF/papers/SIG19/lffusion/testscene.zip
unzip testscene.zip
cd ..
