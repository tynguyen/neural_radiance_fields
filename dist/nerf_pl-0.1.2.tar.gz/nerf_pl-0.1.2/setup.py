# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['nerf_pl',
 'nerf_pl.LLFF',
 'nerf_pl.LLFF.llff',
 'nerf_pl.LLFF.llff.inference',
 'nerf_pl.LLFF.llff.math',
 'nerf_pl.LLFF.llff.poses',
 'nerf_pl.datasets',
 'nerf_pl.datasets..ipynb_checkpoints',
 'nerf_pl.models',
 'nerf_pl.utils']

package_data = \
{'': ['*'],
 'nerf_pl': ['.github/*',
             '.github/ISSUE_TEMPLATE/*',
             '.ipynb_checkpoints/*',
             '.vscode/*',
             'colab_notebooks/*',
             'docs/*',
             'scripts/*'],
 'nerf_pl.LLFF': ['checkpoints/*',
                  'cuda_renderer/*',
                  'cuda_renderer/glm/*',
                  'cuda_renderer/glm/detail/*',
                  'cuda_renderer/glm/ext/*',
                  'cuda_renderer/glm/gtc/*',
                  'cuda_renderer/glm/gtx/*',
                  'cuda_renderer/glm/simd/*',
                  'docker/*',
                  'opengl_viewer/*',
                  'opengl_viewer/glad/*',
                  'opengl_viewer/glm/*',
                  'opengl_viewer/glm/detail/*',
                  'opengl_viewer/glm/ext/*',
                  'opengl_viewer/glm/gtc/*',
                  'opengl_viewer/glm/gtx/*',
                  'opengl_viewer/glm/simd/*',
                  'opengl_viewer/utils/*']}

install_requires = \
['PyMCubes>=0.1.2,<0.2.0',
 'SoundFile>=0.10.3.post1,<0.11.0',
 'imageio>=2.9.0,<3.0.0',
 'jupyter>=1.0.0,<2.0.0',
 'kornia==0.2.0',
 'matplotlib>=3.4.2,<4.0.0',
 'open3d>=0.13.0,<0.14.0',
 'opencv-python==4.2.0.34',
 'plyfile>=0.7.4,<0.8.0',
 'pycollada>=0.7.1,<0.8.0',
 'pyglet>=1.5.15,<2.0.0',
 'pytorch-lightning==1.4.2',
 'scikit-image>=0.18.2,<0.19.0',
 'test-tube>=0.7.5,<0.8.0',
 'torch==1.9.0',
 'torchsearchsorted @ '
 'git+https://github.com/aliutkus/torchsearchsorted.git@1e0ffc3e0663ffda318b4e28348efd90313d08f3',
 'torchvision==0.10.0',
 'trimesh>=3.9.24,<4.0.0']

setup_kwargs = {
    'name': 'nerf-pl',
    'version': '0.1.2',
    'description': 'This is a simple Pytorch implementation of visual NeRF',
    'long_description': None,
    'author': 'tynguyen',
    'author_email': 'tynguyen@seas.upenn.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
