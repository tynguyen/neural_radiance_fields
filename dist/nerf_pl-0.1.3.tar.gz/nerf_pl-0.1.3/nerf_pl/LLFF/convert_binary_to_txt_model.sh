# Convert colmap reconstruction from binary format to .txt format
colmap model_converter \
     --input_path ../data/replica/room_0/sparse/0 \
     --output_path ../data/replica/room_0/sparse/0 \
     --output_type TXT
